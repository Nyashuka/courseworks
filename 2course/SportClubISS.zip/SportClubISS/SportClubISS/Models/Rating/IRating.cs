﻿namespace SportClubISS.Models.Rating;

public interface IRating
{
    float GetRatingScore();
}