﻿namespace SportClubISS.Models.Competitions;

public enum CompetitionStatus
{
    Planned,
    Completed,
    Postponed,
    Finished
}